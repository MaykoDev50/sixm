SIXM SERVER
===========

1. Put this folder somewhere simple, like C:\SixmServer (not inside Program Files).
2. Run SixmServer.exe. It updates itself automatically.
3. Create your admin account (the PIN is filled in for you).
4. Follow the setup: pick a name and map, press "Install server", then Start.

Panel in any browser: http://localhost:40120
Ports to open in your router for players: 27015 and 27016 (UDP).
