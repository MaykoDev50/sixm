SIXM SERVER
===========

1. Put this folder somewhere simple, like C:\SixmServer (not inside Program Files).
2. Run SixmServer.exe.
3. Create your admin account (the PIN is filled in for you).
4. Follow the setup: pick a name and map, press "Install server", then Start.

The panel also works from any browser: http://localhost:40120
From another computer: http://YOUR-IP:40120 (the PIN and address are in the window title).

Ports to open in your router for players: 27015 and 27016 (UDP).
