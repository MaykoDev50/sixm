SIXM
====

Run Sixm.exe. Requires Windows 10/11 and Unturned installed through Steam (free).

Files you can edit (next to Sixm.exe):
  servers.json   Servers shown in the launcher.
  config.json    updateUrl, serverListUrl (central server list), news.

Shortcuts: F5 refresh, F8 direct connect.

Sixm updates itself. When a new version is published it downloads on start-up.
